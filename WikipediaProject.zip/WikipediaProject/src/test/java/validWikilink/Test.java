package validWikilink;

import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.opencsv.CSVWriter;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Test {
	static WebDriver driver ;

	/**
	 * @methodName : getStatusCode
	 * @Description : This method is used to return status code				
	 * @param url
	 * @return status code
	 */
	public int getStatusCode(String url) {
		int intCode = 0;
		try {
			HttpURLConnection urlConn = (HttpURLConnection) (new URL(url).openConnection());
			urlConn.setRequestMethod("HEAD");
			urlConn.connect();
			intCode = urlConn.getResponseCode();
		} catch (Exception e) {

		}
		return intCode;
	}
	
	/**
	 * @methodName : getLinks
	 * @Description : This method is used to fetch all the links URl and stored into list (data structure)			
	 * @return List<String>
	 */
	public List<String>  getLinks() {
		List<String> allLinksURL = new ArrayList<String>();
		List<WebElement> links = driver.findElements(By.tagName("a"));
		 Iterator<WebElement> itr = links.iterator();  
		 //5) This process should terminate after n cycles.
	        while(itr.hasNext()){          
	            String url = itr.next().getAttribute("href"); 
	            	allLinksURL.add(url);	            
	        }
		return allLinksURL;  
	}
	
	
	/**
	 * @methodName : verifyValidLinks
	 * @Description : This method is used to verify whether link is valid or not. if valid throws exception and print Exception message			
	 * @param statusCode
	 * @param url
	 */
	public void verifyValidLinks(int statusCode, String url) {
		try {
			if(statusCode!=200){
				 //print the link if it is not valid
	             System.out.println(url+" is a broken link");
	             throw new RuntimeException(url+" is a broken link");
	         }
	         else{
	             System.out.println(url+" is a valid link");
	         }
		}catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println(url+" is a broken link");
		}
		 
	}
	
	/**
	 * @methodName : getDriver
	 * @Description : This method is used to create chrome driver				
	 * @return WebDriver
	 */
	public WebDriver getDriver() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		return driver;
	}
	

	/**
	 * @methodName : quitDriver
	 * @Description : This method is used to close driver			
	 */
	public void quitDriver() {
	  driver.quit();;
	}
	
	/**
	 * @methodName : launchURL
	 * @Description : This method is used to invoke app url			
	 * @param appURL
	 */
	public void launchURL(String appURL) {
		getDriver().get(appURL);
	}
	
	/**
	 * @methodName : storeAllLinks
	 * @Description : This method is used to store all the links URL into list			
	 * @param url
	 * @return List<String>
	 */
	public List<String>  storeAllLinks(String notToVistURL) {
		List<String> allLinksURL = new ArrayList<String>();
		List<WebElement> links = driver.findElements(By.tagName("a"));
		 Iterator<WebElement> itr = links.iterator();  
		 //2) Accepts a valid integer between 1 to 20 - call it n
		 //5) This process should terminate after n cycles.
	        while(itr.hasNext()){          
	            String url = itr.next().getAttribute("href"); 
	            //1) Not to visit any links you've already visited.
	            if(!url.contentEquals(notToVistURL)) {
	            	allLinksURL.add(url);
	            }	            
	        }
		return allLinksURL;  
	}
	
	
	/**
	 * @methodName : writeLinksDetailsIntoCSV
	 * @Description : This method is used to write the links url and total links count in csv file	
	 * @location : \\src\\test\\resources\\CSV\\data.csv
	 */
	public void writeLinksDetailsIntoCSV() throws IOException {
		List<String> allURLs = new ArrayList<String>();
		FileWriter outputfile = new FileWriter(System.getProperty("user.dir")+"\\src\\test\\resources\\CSV\\data.csv");
        CSVWriter writer = new CSVWriter(outputfile);

        String[] header = { "All_Found_Links", "TotalCount"};
        writer.writeNext(header);
        allURLs = getLinks();
        
        List<String[]> rows = new LinkedList<String[]>();
        String totalLinks ="" ;
        for(String link : allURLs) {       	
        	if(totalLinks.contentEquals("")) {
        		totalLinks =  String.valueOf(allURLs.size());
            	rows.add(new String[]{link,String.valueOf(allURLs.size())});
        	}else {
            	rows.add(new String[]{link});
        	}        	
        }
        writer.writeAll(rows);
        writer.close();
	}
	
	
	public static void main(String[] args) throws IOException {
		Test obj = new Test();
	
		String strURL = "https://www.facebook.com/local/lists/245019872666104/";
		obj.launchURL(strURL);
		//1) Accepts a Wikipedia link - return/throw an error if the link is not a valid wiki link
		obj.verifyValidLinks(obj.getStatusCode(strURL), strURL);
		obj.quitDriver();
		
		//---------------------------------------------------------------
		//3) Scrape the link provided in Step 1, for all wiki links embedded in the page and store them in a data structure of your choice
		obj.launchURL("https://www.facebook.com/login/");
		//4) Repeat Step 3 for all newly found links and store them in the same data structure.
		System.out.println(obj.storeAllLinks(strURL));
		
		//Write the results  to a CSV file.
		obj.writeLinksDetailsIntoCSV();
		
		obj.quitDriver();
		
		
       
		

	}

}
